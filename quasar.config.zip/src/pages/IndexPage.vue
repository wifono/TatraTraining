<template>
  <div id="wrap">
    <div class="tb-head">
      <div class="status-bar">
        <div class="status-item free">{{ freeCount }}</div>
        <div class="status-item occupied">{{ occupiedCount }}</div>
        <div class="datetime-left">
          <div class="time-left">{{ currentTime }}</div>
          <div class="date-left">{{ currentDate }}</div>
        </div>
      </div>
    </div>

    <div class="schedule">
      <div class="room-labels">
        <div v-for="room in uniqueRooms" :key="room.name" class="room-label">
          <q-icon :name="room.arrow" color="white" size="20px" class="room-icon" />
          <span>{{ room.name }}</span>
        </div>
      </div>

      <div class="event-grid">
        <div v-for="room in uniqueRooms" :key="room.name" class="room-row">
          <template v-if="getRoomEvents(room).length === 0">
            <div class="event-slot full free">
              <div class="event-details">Free</div>
            </div>
          </template>
          <template v-else-if="getRoomEvents(room).length === 1">
            <template v-if="isBeforeEvent(room)">
              <div class="event-slot free">
                <div class="event-details">Free</div>
              </div>
              <div class="event-slot occupied">
                <div class="event-details">
                  <div class="event-title">{{ getRoomEvents(room)[0].subject }}</div>
                  <div class="event-time">{{ getRoomEvents(room)[0].start }} - {{ getRoomEvents(room)[0].end }}</div>
                </div>
              </div>
            </template>
            <template v-else>
              <div class="event-slot occupied">
                <div class="event-details">
                  <div class="event-title">{{ getRoomEvents(room)[0].subject }}</div>
                  <div class="event-time">{{ getRoomEvents(room)[0].start }} - {{ getRoomEvents(room)[0].end }}</div>
                </div>
              </div>
              <div class="event-slot free">
                <div class="event-details">Free</div>
              </div>
            </template>
          </template>
          <template v-else>
            <template v-for="(event) in getRoomEvents(room).slice(0,2)" :key="event.id">
              <div class="event-slot occupied">
                <div class="event-details">
                  <div class="event-title">{{ event.subject }}</div>
                  <div class="event-time">{{ event.start }} - {{ event.end }}</div>
                </div>
              </div>
            </template>
          </template>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { reactive, toRefs, computed, onMounted, onBeforeUnmount } from 'vue'
import { useLongPollingStore } from '../stores/LongPollingStore.js'

export default {
  name: 'EventList',

  setup() {
    const longPollingStore = useLongPollingStore()

    const state = reactive({
      currentTime: '',
      currentDate: '',
      currentDateOnly: ''
    })

    const updateDateTime = () => {
      const now = new Date()
      const hours = now.getHours().toString().padStart(2, '0')
      const minutes = now.getMinutes().toString().padStart(2, '0')
      state.currentTime = `${hours}:${minutes}`

      const options = { day: 'numeric', month: 'long', year: 'numeric' }
      state.currentDate = now.toLocaleDateString('sk-SK', options)

      state.currentDateOnly = now.toISOString().split('T')[0]
    }

    let intervalId

    onMounted(() => {
      updateDateTime()
      intervalId = setInterval(updateDateTime, 30000)
      longPollingStore.start()
    })

    onBeforeUnmount(() => {
      clearInterval(intervalId)
    })

    const toMinutes = (time) => {
      const [h, m] = time.split(':').map(Number)
      return h * 60 + m
    }

    const uniqueRooms = computed(() => {
      if (!longPollingStore.events) return []
      const rooms = []
      longPollingStore.events.forEach(e => {
        if (!rooms.find(r => r.name === e.location)) {
          rooms.push({ name: e.location, arrow: e.arrow })
        }
      })
      return rooms
    })

    const getRoomEvents = (room) => {
      const nowDate = state.currentDateOnly
      return (longPollingStore.events || [])
        .filter(e => e.location === room.name)
        .filter(e => {
          const eventDate = e.date ? e.date : state.currentDateOnly
          return eventDate === nowDate
        })
        .filter(e => {
          const endTime = toMinutes(e.end)
          const nowTime = toMinutes(state.currentTime)
          return nowTime <= endTime
        })
        .sort((a, b) => toMinutes(a.start) - toMinutes(b.start))
    }

    const isBeforeEvent = (room) => {
      const events = getRoomEvents(room)
      if (events.length === 0) return false
      const now = toMinutes(state.currentTime)
      const start = toMinutes(events[0].start)
      return now < start - 30
    }

    const isRoomOccupied = (room) => {
      const events = getRoomEvents(room)
      const now = toMinutes(state.currentTime)
      return events.some(event => {
        const start = toMinutes(event.start)
        const end = toMinutes(event.end)
        return now >= start - 30 && now <= end
      })
    }

    const freeCount = computed(() => {
      return uniqueRooms.value.filter(room => {
        const events = getRoomEvents(room)
        if (events.length === 0) return true
        return !isRoomOccupied(room)
      }).length
    })

    const occupiedCount = computed(() => {
      return uniqueRooms.value.filter(room => isRoomOccupied(room)).length
    })

    return {
      ...toRefs(state),
      longPollingStore,
      uniqueRooms,
      getRoomEvents,
      isBeforeEvent,
      freeCount,
      occupiedCount
    }
  }
}
</script>

<style scoped>
#wrap {
  font-family: Arial, sans-serif;
  background-color: black;
  color: white;
  min-height: 100vh;
}

.tb-head {
  display: flex;
  align-items: center;
  justify-content: flex-start;
  padding: 10px;
}

.status-bar {
  display: flex;
  align-items: center;
}

.status-item {
  width: 40px;
  height: 40px;
  font-size: 20px;
  font-weight: bold;
  color: white;
  display: flex;
  align-items: center;
  justify-content: center;
  margin-right: 10px;
  border-radius: 4px;
}

.datetime-left {
  display: flex;
  flex-direction: column;
  margin-left: 20px;
}

.time-left {
  font-size: 20px;
}

.date-left {
  font-size: 12px;
}

.schedule {
  display: flex;
  width: 100%;
  gap : 0.15em;
}

.room-labels {
  display: flex;
  flex-direction: column;
  gap : 0.15em;
}

.room-label {
  height: 60px;
  width: 115px;
  display: flex;
  align-items: center;
  justify-content: flex-start;
  background-color: purple;
  color: white;
  font-weight: bold;

  /* border-left: 2px solid black;
  border-bottom: 2px solid black; */
  padding-left: 10px;
}

.room-icon {
  margin-right: 8px;
}

.event-grid {
  display: flex;
  flex-direction: column;
  flex: 1;
  gap : 0.15em;
}

.room-row {
  display: flex;
  flex-wrap: nowrap;
  width: 100%;
  gap : 0.15em;
}

.event-slot {
  flex: 1 1 auto;
  min-width: 100px;
  height: 60px;
  /* border: 1px solid #ddd; */
  position: relative;
}

.full {
  flex: 1 1 100%;
}

.free {

  background-color: green;
}

.event-slot.free .event-details {
  position: absolute;           /* Zruší absolútne umiestnenie len pre Free */
  display: flex;              /* Aktivuje flexbox */
  justify-content: flex-start;    /* Horizontálne centrovanie */
  align-items: center;        /* Vertikálne centrovanie */
  font-size: 16px;
  padding-left: 0.5em;
  padding-top: 0.8em;
  font-weight: bold;
  color: white;
}

.occupied {
  background-color: red;
  color: white;
}

.event-details {
  position: absolute;
  top: 5px;
  left: 5px;
  font-size: 12px;
}

.event-title {
font-weight: 700;
font-size: 1.25em;
}

.event-time {
  font-size: 10px;
  font-size: 1em;
}
</style>
