import { defineStore } from 'pinia'
import dayjs from 'dayjs'
import { api } from '../boot/axios.js'

const id = new URL(location.href).searchParams.get('id') || window.location.pathname.split('/').pop()

api.defaults.timeout = 30000
api.interceptors.response.use(
  (response) => response,
  (error) => {
    console.log(error)
    return Promise.reject(error)
  }
)

export const useLongPollingStore = defineStore('longPolling', {
  actions: {
    start() {
      this.runCommand(this.dispatch)
    },

    async runCommand(dispatch) {
      const op = { timeout: 30000 }
      try {
        // const res = await api.get(id + '?timestamp=' + dayjs().unix(), op)
        // console.log(res.data[0])
        // this.events = res.data[0].events.map((event) => {
        //   const dateRegex = /\d{1,2}\.\d{1,2}\.\d{4}/
        //   const dateMatch = event.start.match(dateRegex)
        //   const startDate = dateMatch ? dateMatch[0] : ''
        //   const startTime = event.start.replace(startDate, '').trim()

        //   return {
        //     ...event,
        //     start: startTime
        //   }
        // })
        this.events = [
          {
            id: 1,
            start: '10:00',
            end: '12:00',
            subject: 'Presne toto chceme myyyyy',
            location: 'Archív',
            arrow: 'arrow_back'
          },
          {
            id: 2,
            start: '19:00',
            end: '20:00',
            subject: 'Byť bohaty a uspesnyyyy',
            location: 'Galéria',
            arrow: 'south'
          },
          {
            id: 3,
            start: '9:00',
            end: '16:00',
            subject: 'Peniaze krasne ženyyyyyyyyy',
            location: 'Most',
            arrow: 'turn_right'
          },
          {
            id: 4,
            start: '12:00',
            end: '22:00',
            subject: 'Byť zadanynezadanyy',
            location: 'Rozhlas',
            arrow: 'turn_left'
          },
          {
            id: 5,
            start: '12:00',
            end: '22:00',
            subject: 'Byť zadanynezadanyy',
            location: 'Televízia',
            arrow: 'north'
          },
          {
            id: 6,
            start: '12:00',
            end: '22:00',
            subject: 'Byť zadanynezadanyy',
            location: 'Veža',
            arrow: 'north'
          },
          {
            id: 15987,
            start: '23:00',
            end: '23:30',
            subject: 'Byť zadanynezadanyy',
            location: 'Veža',
            arrow: 'north'
          }
        ]
        dispatch('execCommand', res.data)
      } catch (error) {
        if (error.code === 'ECONNABORTED') {
          console.log('runCommand timeout')
        }
      } finally {
        setTimeout(() => this.runCommand(dispatch), 30000)
      }
    },

    execCommand({ commit }, data) {
      commit('updateEvents', data)
    }
  }
})
